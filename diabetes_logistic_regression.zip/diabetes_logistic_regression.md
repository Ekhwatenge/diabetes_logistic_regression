```python
# Importing necessary libraries
import pandas as pd  # pandas is used for data manipulation and analysis
import numpy as np   # numpy is used for numerical computations
from sklearn.model_selection import train_test_split  # For splitting data into training and testing sets
from sklearn.preprocessing import StandardScaler     # For scaling numerical features
from sklearn.linear_model import LogisticRegression  # Logistic Regression model for classification
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix # To evaluate the model
import matplotlib.pyplot as plt # For creating visualizations
import seaborn as sns           # For making statistical graphics

# Load the dataset
try:
    data = pd.read_csv('diabetes_dataset.csv')
except FileNotFoundError:
    print("Error: diabetes_dataset.csv not found.  Make sure the file is in the same directory as your notebook, or provide the correct path.")
    exit()
except Exception as e:
    print(f"An error occurred while loading the dataset: {e}")
    exit()
```


```python
# Display the first few rows of the dataframe to understand its structure
print("First 5 rows of the dataset:")
print(data.head())

# Summary statistics of the dataset
print("\nSummary statistics of the dataset:")
print(data.describe())

# Check for missing values
print("\nMissing values in the dataset:")
print(data.isnull().sum())

# Data Cleaning (if needed - handling outliers or incorrect data types)
# For simplicity, we'll skip complex cleaning for now, but in a real project, this is crucial

# Feature Engineering (creating new features if needed)
# For this example, we will skip feature engineering

# Select features (X) and target variable (y)
# 'Outcome' is our target variable - whether or not someone has diabetes
X = data.drop('Outcome', axis=1)  # Features: all columns except 'Outcome'
y = data['Outcome']               # Target: 'Outcome' column

# Split data into training and testing sets
# We'll use 80% of the data for training and 20% for testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Feature scaling using StandardScaler
# StandardScaler scales features to have mean=0 and variance=1
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train) # Fit on training data and transform
X_test = scaler.transform(X_test)       # Transform test data using the fitted scaler

# Initialize and train the Logistic Regression model
# Logistic Regression is a linear model used for binary classification
model = LogisticRegression(random_state=42) #initialize the model
model.fit(X_train, y_train) # Train the model using training data



```

    First 5 rows of the dataset:
       Age  Pregnancies    BMI  Glucose  BloodPressure  HbA1c    LDL   HDL  \
    0   69            5  28.39    130.1           77.0    5.4  130.4  44.0   
    1   32            1  26.49    116.5           72.0    4.5   87.4  54.2   
    2   89           13  25.34    101.0           82.0    4.9  112.5  56.8   
    3   78           13  29.91    146.0          104.0    5.7   50.7  39.1   
    4   38            8  24.56    103.2           74.0    4.7  102.5  29.1   
    
       Triglycerides  WaistCircumference  HipCircumference   WHR  FamilyHistory  \
    0           50.0                90.5             107.9  0.84              0   
    1          129.9               113.3              81.4  1.39              0   
    2          177.6                84.7             107.2  0.79              0   
    3          117.0               108.9             110.0  0.99              0   
    4          145.9                84.1              92.8  0.91              0   
    
       DietType  Hypertension  MedicationUse  Outcome  
    0         0             0              1        0  
    1         0             0              0        0  
    2         0             0              1        0  
    3         0             0              1        1  
    4         1             0              0        0  
    
    Summary statistics of the dataset:
                   Age  Pregnancies          BMI      Glucose  BloodPressure  \
    count  9538.000000  9538.000000  9538.000000  9538.000000    9538.000000   
    mean     53.577584     7.986161    27.052364   106.104183      84.475781   
    std      20.764651     4.933469     5.927955    21.918590      14.123480   
    min      18.000000     0.000000    15.000000    50.000000      60.000000   
    25%      36.000000     4.000000    22.870000    91.000000      74.000000   
    50%      53.000000     8.000000    27.050000   106.000000      84.000000   
    75%      72.000000    12.000000    31.180000   121.000000      94.000000   
    max      89.000000    16.000000    49.660000   207.200000     138.000000   
    
                 HbA1c          LDL          HDL  Triglycerides  \
    count  9538.000000  9538.000000  9538.000000    9538.000000   
    mean      4.650661   100.133456    49.953418     151.147746   
    std       0.476395    29.911910    15.242194      48.951627   
    min       4.000000   -12.000000    -9.200000      50.000000   
    25%       4.300000    80.100000    39.700000     117.200000   
    50%       4.600000    99.900000    50.200000     150.550000   
    75%       5.000000   120.200000    60.200000     185.100000   
    max       6.900000   202.200000   107.800000     345.800000   
    
           WaistCircumference  HipCircumference          WHR  FamilyHistory  \
    count         9538.000000       9538.000000  9538.000000    9538.000000   
    mean            93.951678        103.060621     0.917400       0.302474   
    std             15.594468         13.438827     0.140828       0.459354   
    min             40.300000         54.800000     0.420000       0.000000   
    25%             83.400000         94.000000     0.820000       0.000000   
    50%             93.800000        103.200000     0.910000       0.000000   
    75%            104.600000        112.100000     1.010000       1.000000   
    max            163.000000        156.600000     1.490000       1.000000   
    
              DietType  Hypertension  MedicationUse      Outcome  
    count  9538.000000   9538.000000    9538.000000  9538.000000  
    mean      0.486161      0.001048       0.405012     0.344097  
    std       0.661139      0.032364       0.490920     0.475098  
    min       0.000000      0.000000       0.000000     0.000000  
    25%       0.000000      0.000000       0.000000     0.000000  
    50%       0.000000      0.000000       0.000000     0.000000  
    75%       1.000000      0.000000       1.000000     1.000000  
    max       2.000000      1.000000       1.000000     1.000000  
    
    Missing values in the dataset:
    Age                   0
    Pregnancies           0
    BMI                   0
    Glucose               0
    BloodPressure         0
    HbA1c                 0
    LDL                   0
    HDL                   0
    Triglycerides         0
    WaistCircumference    0
    HipCircumference      0
    WHR                   0
    FamilyHistory         0
    DietType              0
    Hypertension          0
    MedicationUse         0
    Outcome               0
    dtype: int64
    




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(random_state=42)</pre></div></div></div></div></div>




```python
# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
print("\nModel Evaluation:")
print("Accuracy:", accuracy_score(y_test, y_pred)) # Overall accuracy of the model

# Detailed classification report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Confusion matrix to visualize True Positives, True Negatives, False Positives, and False Negatives
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Optional: Visualize the Confusion Matrix using Seaborn
conf_matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()

```

    
    Model Evaluation:
    Accuracy: 0.9931865828092243
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0       0.99      1.00      0.99      1275
               1       1.00      0.98      0.99       633
    
        accuracy                           0.99      1908
       macro avg       0.99      0.99      0.99      1908
    weighted avg       0.99      0.99      0.99      1908
    
    
    Confusion Matrix:
    [[1274    1]
     [  12  621]]
    


    
![png](output_2_1.png)
    



```python
# Example of predicting for a new patient
# The values should be preprocessed (scaled) in the same way as the training data
new_patient_data = np.array([60, 5, 30.0, 120.0, 80.0, 5.0, 100.0, 50.0, 150.0, 90.0, 100.0, 0.9, 0, 1, 0, 0]).reshape(1, -1)
new_patient_data_scaled = scaler.transform(new_patient_data)
prediction = model.predict(new_patient_data_scaled)

print("\nPrediction for a new patient:", prediction[0])
if prediction[0] == 1:
    print("The model predicts this patient has diabetes.")
else:
    print("The model predicts this patient does not have diabetes.")
```

    
    Prediction for a new patient: 0
    The model predicts this patient does not have diabetes.
    

    C:\Users\elvir\anaconda3\Lib\site-packages\sklearn\base.py:439: UserWarning: X does not have valid feature names, but StandardScaler was fitted with feature names
      warnings.warn(
    


```python

```
